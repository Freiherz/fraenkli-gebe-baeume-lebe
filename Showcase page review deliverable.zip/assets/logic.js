/* PREVIEW STUB — replace with the project's real assets/logic.js. */
window.LOGIC = {
  isClosed: function (deadlineIso, now) {
    return (now || new Date()) > new Date(deadlineIso);
  },
  validate: function (data) {
    var emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email || '');
    var phoneOk = ((data.phone || '').replace(/\D/g, '').length >= 9);
    var donatedOk = data.donated === 'yes' || data.donated === 'no';
    var consentOk = !!data.consent;
    return emailOk && phoneOk && donatedOk && consentOk;
  },
  formatDeadline: function (iso, lang, tz) {
    return new Intl.DateTimeFormat({ de: 'de-CH', fr: 'fr-CH', en: 'en-GB' }[lang] || 'de-CH', {
      weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit', timeZone: tz || 'Europe/Zurich'
    }).format(new Date(iso));
  }
};
