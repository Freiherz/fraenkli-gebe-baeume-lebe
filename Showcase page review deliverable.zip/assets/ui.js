/* assets/ui.js — presentation-only: scroll reveals, success morph, optional theme override.
   No dependency on app.js; safe to keep alongside the existing scripts. */
(function () {
  var html = document.documentElement;
  html.classList.add('js');

  // ?theme=dark|light forces a color scheme (used for previews / QA)
  var theme = new URLSearchParams(location.search).get('theme');
  if (theme === 'dark' || theme === 'light') html.dataset.theme = theme;

  // Scroll reveals, once
  var targets = document.querySelectorAll('[data-reveal]');
  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) { e.target.classList.add('is-visible'); io.unobserve(e.target); }
      });
    }, { rootMargin: '0px 0px -10% 0px', threshold: 0.08 });
    targets.forEach(function (t) { io.observe(t); });
  } else {
    targets.forEach(function (t) { t.classList.add('is-visible'); });
  }

  // Success morph: when app.js tags the status with data-kind="ok", collapse the form into a card
  var form = document.getElementById('entry');
  var status = form && form.querySelector('.status');
  if (status && 'MutationObserver' in window) {
    new MutationObserver(function () {
      form.classList.toggle('is-success', status.dataset.kind === 'ok');
    }).observe(status, { attributes: true, attributeFilter: ['data-kind'] });
  }
})();
