/* PREVIEW STUB — replace with the project's real assets/app.js.
   Demonstrates the hook contract: language switch, i18n injection, deadline, donated toggle, status kinds. */
(function () {
  var cfg = window.APP_CONFIG || {};
  var I18N = window.I18N || {};
  var L = window.LOGIC;
  var lang = (new URLSearchParams(location.search).get('lang')) || (localStorage.getItem('fgbl-lang')) || 'de';
  if (!I18N[lang]) lang = 'de';

  function t(key) { var d = I18N[lang] || {}; return d[key]; }

  function apply() {
    document.documentElement.lang = lang;
    document.querySelectorAll('[data-i18n]').forEach(function (el) { var v = t(el.dataset.i18n); if (v != null) el.textContent = v; });
    document.querySelectorAll('[data-i18n-placeholder]').forEach(function (el) { var v = t(el.dataset.i18nPlaceholder); if (v != null) el.placeholder = v; });
    document.querySelectorAll('[data-i18n-alt]').forEach(function (el) { var v = t(el.dataset.i18nAlt); if (v != null) el.alt = v; });
    document.querySelectorAll('[data-i18n-list]').forEach(function (el) {
      var items = t(el.dataset.i18nList);
      if (!Array.isArray(items)) return;
      el.innerHTML = '';
      items.forEach(function (s) { var li = document.createElement('li'); li.textContent = s; el.appendChild(li); });
    });
    document.querySelectorAll('.lang-switch [data-lang]').forEach(function (b) { b.setAttribute('aria-pressed', String(b.dataset.lang === lang)); });
    var dl = document.getElementById('deadline');
    if (dl && cfg.deadline) dl.textContent = L.formatDeadline(cfg.deadline, lang, cfg.timezone);
    if (status.dataset.kind) setStatus(status.dataset.kind);
  }

  document.querySelectorAll('.lang-switch [data-lang]').forEach(function (b) {
    b.addEventListener('click', function () { lang = b.dataset.lang; localStorage.setItem('fgbl-lang', lang); apply(); });
  });

  var form = document.getElementById('entry');
  var status = form.querySelector('.status');
  var details = document.getElementById('donation-details');

  function setStatus(kind) { status.dataset.kind = kind; status.textContent = t('status.' + kind) || kind; }

  form.querySelectorAll('input[name="donated"]').forEach(function (r) {
    r.addEventListener('change', function () {
      var yes = form.donated.value === 'yes';
      details.hidden = !yes;
      details.querySelectorAll('input, textarea').forEach(function (f) { f.required = yes; });
    });
  });

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    if (form.website.value) return; // honeypot
    if (L.isClosed(cfg.deadline)) return setStatus('closed');
    var data = {
      email: form.email.value.trim(), phone: form.phone.value.trim(),
      donated: form.donated.value, why: form.why.value, amount: form.amount.value,
      consent: form.consent.checked
    };
    if (!L.validate(data)) { form.reportValidity(); return setStatus('invalid'); }
    setStatus('pending');
    // Demo only: pretend to POST. Real app.js talks to cfg.endpoint.
    setTimeout(function () {
      var seen = JSON.parse(localStorage.getItem('fgbl-demo-entries') || '[]');
      if (seen.indexOf(data.email.toLowerCase()) >= 0) return setStatus('duplicate');
      seen.push(data.email.toLowerCase());
      localStorage.setItem('fgbl-demo-entries', JSON.stringify(seen));
      setStatus('ok');
    }, 900);
  });

  apply();
})();
